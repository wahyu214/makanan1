package com.example.makanan_kami

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
